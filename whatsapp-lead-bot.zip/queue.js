/**
 * 100% Real Human Anti-Ban Queue Dispatcher (50 Leads / Day Master Formula)
 * 
 * Rules for 100% Ban Immunity on 1 Number:
 * 1. 50 Verified Indian Leads Max per 24 hours
 * 2. Active strictly during Indian Daytime (9:00 AM to 9:30 PM IST) - Human Night Sleep Mode
 * 3. 1 message every 1 to 2 minutes random jitter (60s - 120s)
 * 4. Micro-batches of 5 to 8 messages -> followed by random 50 to 80 minute human tea breaks
 * 5. Two-Step Conversational Shield: respectful inquiry verification (zero spam report risk)
 */

const ai = require('./ai');
const scraper = require('./scraper');

const DAILY_MAX_LEADS = parseInt(process.env.DAILY_MAX_LEADS || '50', 10); // 50 leads / 24 hrs
const MIN_MSG_DELAY_MS = parseInt(process.env.MIN_MSG_DELAY_MS || '60000', 10); // 1 minute (60s)
const MAX_MSG_DELAY_MS = parseInt(process.env.MAX_MSG_DELAY_MS || '120000', 10); // 2 minutes (120s)
const MIN_BREAK_MINS = parseInt(process.env.MIN_BREAK_MINS || '50', 10); // 50 mins
const MAX_BREAK_MINS = parseInt(process.env.MAX_BREAK_MINS || '80', 10); // 80 mins
const MIN_BATCH_SIZE = parseInt(process.env.MIN_BATCH_SIZE || '5', 10);
const MAX_BATCH_SIZE = parseInt(process.env.MAX_BATCH_SIZE || '8', 10);

let isRunning = false;
let isPaused = false;
let isProactiveScraping = false;
let currentBatchCount = 0;
let currentBatchLimit = getRandomBatchLimit();
let consecutiveFailures = 0;
let totalSentSession = 0;
let dailySentCount = 0;
let currentDay = new Date().toDateString();
let nextActionTime = null;
let currentStatus = 'Idle';

function getRandomBatchLimit() {
  return Math.floor(MIN_BATCH_SIZE + Math.random() * (MAX_BATCH_SIZE - MIN_BATCH_SIZE + 1));
}

function getRandomMsgDelayMs() {
  return Math.floor(MIN_MSG_DELAY_MS + Math.random() * (MAX_MSG_DELAY_MS - MIN_MSG_DELAY_MS + 1));
}

function getRandomBreakDurationMs() {
  const mins = MIN_BREAK_MINS + Math.random() * (MAX_BREAK_MINS - MIN_BREAK_MINS);
  return Math.floor(mins * 60 * 1000);
}

function getIndianTimeParts() {
  const now = new Date();
  const istStr = now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
  const istDate = new Date(istStr);
  return {
    hour: istDate.getHours(),
    minute: istDate.getMinutes(),
    dateStr: istDate.toDateString(),
    now
  };
}

/**
 * Returns true if current time is between 9:00 AM and 9:30 PM IST (Normal Human Clinic Hours)
 */
function isIndianDaytime() {
  const { hour, minute } = getIndianTimeParts();
  return (hour >= 9 && (hour < 21 || (hour === 21 && minute <= 30)));
}

/**
 * Calculate timestamp for next 9:00 AM IST
 */
function getNext9AmIstTimestamp() {
  const now = new Date();
  const istStr = now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
  const istDate = new Date(istStr);

  const target = new Date(istDate);
  if (istDate.getHours() >= 9) {
    target.setDate(target.getDate() + 1);
  }
  target.setHours(9, 0, 0, 0);

  const diffMs = target.getTime() - istDate.getTime();
  return Date.now() + Math.max(diffMs, 60000);
}

function checkAndResetDailyCounter() {
  const { dateStr } = getIndianTimeParts();
  if (dateStr !== currentDay) {
    currentDay = dateStr;
    dailySentCount = 0;
    currentBatchCount = 0;
    currentBatchLimit = getRandomBatchLimit();
    console.log(`🌅 [Anti-Ban Engine] New IST calendar day. Outreach counter reset to 0/${DAILY_MAX_LEADS}`);
  }
}

/**
 * Format timestamp into exact Indian Standard Time (IST, 12-hour format)
 */
function formatIndiaTime(timestamp) {
  if (!timestamp) return null;
  try {
    return new Date(timestamp).toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }) + ' IST';
  } catch (e) {
    return new Date(timestamp).toLocaleTimeString('en-IN') + ' IST';
  }
}

function getQueueState() {
  const db = scraper.loadDatabase();
  const queuedCount = db.leads.filter(l => l.status === 'queued').length;
  const sentCount = db.leads.filter(l => l.status === 'sent').length;
  checkAndResetDailyCounter();

  return {
    isRunning,
    isPaused,
    currentStatus,
    currentBatchCount,
    batchSize: currentBatchLimit,
    dailySentCount,
    dailyMaxLeads: DAILY_MAX_LEADS,
    totalSentSession,
    totalSentDb: sentCount,
    queuedRemaining: queuedCount,
    nextActionTime: formatIndiaTime(nextActionTime),
    isDaytime: isIndianDaytime()
  };
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Start the 100% Real Human Queue Worker
 */
async function startQueueWorker(whatsappClient) {
  if (isRunning) return;
  isRunning = true;
  console.log(`🚀 [Queue Worker] 100% Real Human Anti-Ban Engine Active!`);
  console.log(`📋 Rules: Max 50 leads/day | 1 msg every 1-2 mins random | Mini-batches of 5-8 | 50-80 min breaks | Daytime IST only (9:00 AM - 9:30 PM).`);

  while (isRunning) {
    if (isPaused) {
      currentStatus = 'Paused by User';
      await sleep(5000);
      continue;
    }

    // 1. Check daily calendar reset
    checkAndResetDailyCounter();

    // 2. Daily Anti-Ban 50 Leads Cap
    if (dailySentCount >= DAILY_MAX_LEADS) {
      currentStatus = `Daily Anti-Ban Safety Cap Reached (${dailySentCount}/${DAILY_MAX_LEADS}). Resting safely until tomorrow morning...`;
      nextActionTime = getNext9AmIstTimestamp();
      await sleep(60000);
      continue;
    }

    // 3. Indian Daytime Check (9:00 AM to 9:30 PM IST)
    if (!isIndianDaytime()) {
      currentStatus = '🌙 Night Rest Mode (Human Sleep Simulation). Resuming outreach at 9:00 AM IST...';
      nextActionTime = getNext9AmIstTimestamp();
      await sleep(60000);
      continue;
    }

    // 4. WhatsApp Connection Check
    if (!whatsappClient || !whatsappClient.isConnected()) {
      currentStatus = 'Waiting for WhatsApp Web QR connection...';
      await sleep(10000);
      continue;
    }

    // 5. Proactively top up queue in the background if under 30 leads
    const remainingInQueue = scraper.getQueuedLeads(50).length;
    if (remainingInQueue < 30 && !isProactiveScraping) {
      isProactiveScraping = true;
      console.log(`⚡ [Continuous Scraper] Queue has ${remainingInQueue} leads (<30). Harvesting fresh verified leads in background...`);
      scraper.triggerFreeWebScraper({ targetCount: 30 })
        .catch(e => console.error('Continuous harvest notice:', e.message))
        .finally(() => { isProactiveScraping = false; });
    }

    // 6. Get next queued lead
    let batch = scraper.getQueuedLeads(1);
    if (batch.length === 0) {
      currentStatus = 'Queue Empty: Harvesting fresh Indian business leads (100% Free)...';
      console.log('🔍 [Auto-Scraper] Queue is empty! Automatically triggering Turbo Scraper...');
      try {
        await scraper.triggerFreeWebScraper({ targetCount: 30 });
      } catch (err) {
        console.error('Free Auto-scraper error:', err.message);
        if (process.env.APIFY_API_TOKEN) {
          console.log('⚠️ [Auto-Scraper] Trying Apify fallback...');
          try { await scraper.triggerApifyLeadDiscovery(); } catch (e) {}
        }
      }
      batch = scraper.getQueuedLeads(1);
      if (batch.length === 0) {
        console.log('⏳ [Auto-Scraper] Waiting 20s before next auto-scrape cycle...');
        await sleep(20000);
        continue;
      }
    }

    const lead = batch[0];

    // 7. Strict Indian Number Guard (+91 Only)
    const phoneStr = String(lead.phone).replace(/\D/g, '');
    if (!phoneStr.startsWith('91') || phoneStr.length !== 12) {
      console.log(`❌ [Non-India Lead Skipped] ${lead.phone} is not a valid Indian mobile (+91). Skipping!`);
      scraper.updateLeadStatus(lead.phone, 'not_india');
      continue;
    }

    // 8. Absolute duplicate & older bot shield: Never message anyone already contacted
    if (scraper.isPhoneAlreadySent(lead.phone) || whatsappClient.hasExistingChat(lead.phone) || lead.status === 'sent') {
      console.log(`⏩ [Duplicate / Older Bot Shield] ${lead.phone} was already contacted. Skipping!`);
      scraper.updateLeadStatus(lead.phone, 'sent');
      continue;
    }

    // 9. Verify number is actually registered on WhatsApp
    currentStatus = `Checking WhatsApp status for +${lead.phone}...`;
    const waCheck = await whatsappClient.checkNumberOnWhatsApp(lead.phone);
    if (!waCheck.exists) {
      console.log(`❌ [Not on WhatsApp] +${lead.phone} is a landline or not registered on WhatsApp. Skipping without counting!`);
      scraper.updateLeadStatus(lead.phone, 'not_on_whatsapp');
      await sleep(200);
      continue;
    }

    lead.jid = waCheck.jid;

    // 10. Generate Two-Step Conversational Outreach (Zero Spam Report Risk)
    currentStatus = `Preparing Bemisaal verified outreach for +${lead.phone}...`;
    const outreachText = await ai.generateOutreachMessage(lead);

    // 11. Send via WhatsApp (with real typing & presence telemetry)
    currentStatus = `Sending message to +${lead.phone}...`;
    let sendSucceeded = false;
    try {
      const sent = await whatsappClient.sendTextMessage(lead.jid, outreachText);
      if (sent) {
        scraper.updateLeadStatus(lead.phone, 'sent');
        currentBatchCount++;
        totalSentSession++;
        dailySentCount++;
        consecutiveFailures = 0;
        sendSucceeded = true;
        console.log(`✅ [Real WhatsApp Sent ${currentBatchCount}/${currentBatchLimit}] To +${lead.phone}. Session: ${totalSentSession} | Today: ${dailySentCount}/${DAILY_MAX_LEADS}`);
      } else {
        consecutiveFailures++;
        scraper.updateLeadStatus(lead.phone, 'failed', 'Socket send failure');
      }
    } catch (sendErr) {
      consecutiveFailures++;
      console.error(`❌ [Send Error] Failed to send to +${lead.phone}:`, sendErr.message);
      scraper.updateLeadStatus(lead.phone, 'failed', sendErr.message);
    }

    // Circuit Breaker: If 3 delivery hiccups occur consecutively, cool down the socket for 20 mins to clear any rate limit
    if (consecutiveFailures >= 3) {
      currentStatus = '⚠️ Circuit Breaker engaged (3 delivery hiccups). Cooling down socket for 20 mins for safety...';
      nextActionTime = Date.now() + 20 * 60 * 1000;
      console.log(`\n🛡️ [Circuit Breaker] 3 consecutive delivery hiccups detected. Cooling down socket for 20 mins until ${formatIndiaTime(nextActionTime)}...\n`);
      await sleep(20 * 60 * 1000);
      consecutiveFailures = 0;
    }

    // 12. Human pacing delay or batch break
    if (sendSucceeded) {
      // Check if current mini-batch limit is reached
      if (currentBatchCount >= currentBatchLimit) {
        const breakMs = getRandomBreakDurationMs();
        const breakMins = Math.round(breakMs / 60000);
        nextActionTime = Date.now() + breakMs;
        currentStatus = `Mini-batch of ${currentBatchLimit} delivered! Taking ${breakMins}-min natural tea break...`;
        console.log(`\n☕ [Human Tea Break] Mini-batch hit (${currentBatchLimit} delivered). Taking ${breakMins}-minute break until ${formatIndiaTime(nextActionTime)}...\n`);
        
        await sleep(breakMs);
        
        currentBatchCount = 0;
        currentBatchLimit = getRandomBatchLimit();
        console.log(`⚡ [Queue Worker] Break finished! New batch limit rolled: ${currentBatchLimit} leads.`);
      } else {
        // Random 1 to 2 minutes jitter between messages (60s to 120s)
        const jitterDelayMs = getRandomMsgDelayMs();
        const delaySec = Math.round(jitterDelayMs / 1000);
        nextActionTime = Date.now() + jitterDelayMs;
        currentStatus = `Waiting ${delaySec}s before next lead (1-2 min random jitter)...`;
        console.log(`⏳ [Pacing 1-2m] Next lead scheduled at ${formatIndiaTime(nextActionTime)} (${delaySec}s random delay)...`);
        await sleep(jitterDelayMs);
      }
    } else {
      await sleep(1500);
    }
  }
}

function pauseQueue() {
  isPaused = true;
  console.log('⏸️ [Queue Worker] Paused');
}

function resumeQueue() {
  isPaused = false;
  console.log('▶️ [Queue Worker] Resumed');
}

module.exports = {
  startQueueWorker,
  pauseQueue,
  resumeQueue,
  getQueueState
};
