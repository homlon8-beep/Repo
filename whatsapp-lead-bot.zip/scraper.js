/**
 * Bemisaal Wellness - Indian Health Lead Scraper & Extractor
 * Discovers Indian mobile numbers (91XXXXXXXXXX) interested in Ayurvedic / Herbal Wellness
 * Includes: 24/7 Free Directory Scraper + Apify Google Search Actor backup
 */

const fs = require('fs');
const path = require('path');

const APIFY_TOKEN = process.env.APIFY_API_TOKEN || 'apify_api_ySnZxi6QkAYhVscVz5MTCh67NgsGET2ZFd0F';
const LEADS_FILE = path.join(__dirname, 'leads_db.json');
const BACKUP_FILE = path.join(__dirname, 'leads_db.backup.json');
const SENT_HISTORY_FILE = path.join(__dirname, 'sent_history.json');

let cachedDb = null;

/**
 * Permanent Sent History Tracker (Ensures NO recipient is EVER messaged twice)
 */
function loadSentHistory() {
  try {
    if (fs.existsSync(SENT_HISTORY_FILE)) {
      const raw = fs.readFileSync(SENT_HISTORY_FILE, 'utf8');
      const list = JSON.parse(raw);
      if (Array.isArray(list)) return new Set(list);
    }
  } catch (e) {}
  return new Set();
}

function recordSentPhone(phone) {
  if (!phone) return;
  const digits = String(phone).replace(/\D/g, '');
  const history = loadSentHistory();
  history.add(digits);
  try {
    fs.writeFileSync(SENT_HISTORY_FILE, JSON.stringify([...history], null, 2), 'utf8');
  } catch (e) {}
}

function recordBulkSentPhones(phoneList) {
  if (!Array.isArray(phoneList)) return { added: 0, total: 0 };
  const history = loadSentHistory();
  let added = 0;
  for (const p of phoneList) {
    const digits = String(p).replace(/\D/g, '');
    if (digits && digits.length >= 7 && !history.has(digits)) {
      history.add(digits);
      added++;
    }
  }
  if (added > 0) {
    try {
      fs.writeFileSync(SENT_HISTORY_FILE, JSON.stringify([...history], null, 2), 'utf8');
      console.log(`🛡️ [Sent History Shield] Recorded ${added} past numbers in permanent shield ledger. Total shielded: ${history.size}`);
    } catch (e) {
      console.error('Error saving sent history:', e.message);
    }
  }
  return { added, total: history.size };
}

function getTotalShieldedCount() {
  return loadSentHistory().size;
}

function isPhoneAlreadySent(phone) {
  if (!phone) return false;
  const digits = String(phone).replace(/\D/g, '');
  const history = loadSentHistory();
  return history.has(digits);
}

function loadDatabase() {
  if (cachedDb && cachedDb.leads && Array.isArray(cachedDb.leads)) {
    return cachedDb;
  }
  try {
    if (fs.existsSync(LEADS_FILE)) {
      const raw = fs.readFileSync(LEADS_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.leads)) {
        cachedDb = parsed;
        return cachedDb;
      }
    }
  } catch (err) {
    console.warn('⚠️ [DB Warning] Primary leads_db.json unreadable. Checking backup...', err.message);
  }

  // Fallback to backup file
  try {
    if (fs.existsSync(BACKUP_FILE)) {
      const rawBackup = fs.readFileSync(BACKUP_FILE, 'utf8');
      const parsedBackup = JSON.parse(rawBackup);
      if (parsedBackup && Array.isArray(parsedBackup.leads)) {
        console.log('✅ [DB Recovery] Recovered database from leads_db.backup.json');
        cachedDb = parsedBackup;
        return cachedDb;
      }
    }
  } catch (e) {}

  cachedDb = { leads: [], sentCount: 0 };
  return cachedDb;
}

function saveDatabase(db) {
  cachedDb = db;
  const tempFile = `${LEADS_FILE}.tmp.${Date.now()}`;
  try {
    const payload = JSON.stringify(db, null, 2);
    fs.writeFileSync(tempFile, payload, 'utf8');
    fs.renameSync(tempFile, LEADS_FILE);
    // Mirror backup write
    fs.writeFileSync(BACKUP_FILE, payload, 'utf8');
  } catch (err) {
    console.error('❌ [DB Error] Failed to write leads_db.json safely:', err.message);
    try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (e) {}
  }
}

/**
 * Clean & Format Indian Phone Number into Baileys JID (91XXXXXXXXXX@s.whatsapp.net)
 */
function formatWhatsAppJid(rawNumber) {
  if (!rawNumber) return null;
  let digits = String(rawNumber).replace(/\D/g, '');

  if (digits.startsWith('0') && digits.length === 11) {
    digits = '91' + digits.slice(1);
  } else if (digits.length === 10 && /^[6-9]/.test(digits)) {
    digits = '91' + digits;
  } else if (digits.length === 12 && digits.startsWith('91')) {
    // Already has 91
  } else if (digits.length === 13 && digits.startsWith('091')) {
    digits = digits.slice(1);
  } else {
    return null;
  }

  if (digits.length === 12 && /^91[6-9]\d{9}$/.test(digits)) {
    return {
      cleanNumber: digits,
      jid: `${digits}@s.whatsapp.net`,
      display: `+${digits}`
    };
  }
  return null;
}

/**
 * Add unique leads to database
 */
function addLeadsToQueue(newLeads = []) {
  const db = loadDatabase();
  const existingPhones = new Set(db.leads.map(l => l.phone));
  let added = 0;

  for (const item of newLeads) {
    const formatted = formatWhatsAppJid(item.phone || item.number);
    if (!formatted) continue;

    // Never queue numbers that were already messaged in past sessions
    if (isPhoneAlreadySent(formatted.cleanNumber)) {
      continue;
    }

    if (!existingPhones.has(formatted.cleanNumber)) {
      db.leads.push({
        phone: formatted.cleanNumber,
        jid: formatted.jid,
        name: item.name || 'Bhai',
        source: item.source || 'indian_health_scraper',
        query: item.query || 'ayurvedic wellness',
        discoveredAt: new Date().toISOString(),
        status: 'queued', // queued, sent, replied, not_on_whatsapp, opted_out
        lastSentAt: null
      });
      existingPhones.add(formatted.cleanNumber);
      added++;
    }
  }

  saveDatabase(db);
  console.log(`✅ [Bemisaal Leads DB] Added ${added} new unique Indian leads. Total in DB: ${db.leads.length}`);
  return { added, total: db.leads.length };
}

function getQueuedLeads(limit = 10) {
  const db = loadDatabase();
  return db.leads.filter(l => l.status === 'queued').slice(0, limit);
}

function updateLeadStatus(phone, status, error = null) {
  const db = loadDatabase();
  const cleanDigits = String(phone).replace(/\D/g, '');
  const lead = db.leads.find(l => l.phone === cleanDigits || l.phone === phone || l.jid.includes(cleanDigits));
  if (lead) {
    lead.status = status;
    if (status === 'sent') {
      lead.lastSentAt = new Date().toISOString();
      db.sentCount = (db.sentCount || 0) + 1;
      recordSentPhone(cleanDigits);
    }
    if (error) lead.lastError = error;
    saveDatabase(db);
  }
}

/**
 * 24/7 Continuous Scraper Engine State for Bemisaal Wellness
 */
let is247ScraperRunning = false;
let isScraperPaused = false;
let scraperStats = {
  status: 'Booting 24/7 Engine...',
  cyclesCompleted: 0,
  leadsHarvestedSession: 0,
  totalInDb: 0,
  lastScrapedCity: null,
  lastScrapedNiche: null,
  lastRunTime: null,
  isPaused: false
};

const TARGET_INDIAN_CITIES = [
  'delhi', 'mumbai', 'bangalore', 'hyderabad', 'kolkata',
  'chennai', 'ahmedabad', 'pune', 'lucknow', 'jaipur',
  'patna', 'indore', 'bhopal', 'chandigarh', 'nagpur', 'kanpur'
];

const TARGET_WELLNESS_NICHES = [
  'ayurveda clinic', 'herbal health', 'natural wellness',
  'doctor consultation', 'ayurvedic inquiry', 'general clinic'
];

function getScraperStats() {
  const db = loadDatabase();
  scraperStats.totalInDb = db.leads.length;
  scraperStats.isPaused = isScraperPaused;
  return scraperStats;
}

function pauseScraper() {
  isScraperPaused = true;
  scraperStats.isPaused = true;
  scraperStats.status = 'Scraper Stopped / Paused by User';
  console.log('🛑 [24/7 Scraper] Paused by user.');
}

function resumeScraper() {
  isScraperPaused = false;
  scraperStats.isPaused = false;
  scraperStats.status = 'Resuming autonomous sweeps...';
  console.log('▶️ [24/7 Scraper] Resumed by user.');
}

async function start247ContinuousScraper() {
  if (is247ScraperRunning) return;
  is247ScraperRunning = true;
  console.log('🇮🇳 [24/7 Bemisaal Scraper] Started non-stop autonomous Indian health lead harvest loop!');

  while (is247ScraperRunning) {
    if (isScraperPaused) {
      scraperStats.status = 'Scraper Stopped / Paused by User';
      await new Promise(resolve => setTimeout(resolve, 3000));
      continue;
    }

    try {
      const db = loadDatabase();
      const queuedCount = db.leads.filter(l => l.status === 'queued').length;

      // If backlog is healthy (>= 60 leads queued), rest 2 minutes to keep CPU minimal
      if (queuedCount >= 60) {
        scraperStats.status = `Queue healthy (${queuedCount} Indian leads queued). Resting 2 mins before next sweep...`;
        await new Promise(resolve => setTimeout(resolve, 2 * 60 * 1000));
        continue;
      }

      const city = TARGET_INDIAN_CITIES[Math.floor(Math.random() * TARGET_INDIAN_CITIES.length)];
      const niche = TARGET_WELLNESS_NICHES[Math.floor(Math.random() * TARGET_WELLNESS_NICHES.length)];

      scraperStats.lastScrapedCity = city;
      scraperStats.lastScrapedNiche = niche;
      scraperStats.lastRunTime = new Date().toISOString();
      scraperStats.status = `Scanning ${city.toUpperCase()} for ${niche}...`;

      const result = await triggerFreeWebScraper({
        targetCount: 25,
        targetCity: city,
        targetNiche: niche
      });

      scraperStats.cyclesCompleted++;
      scraperStats.leadsHarvestedSession += (result?.added || 0);
      scraperStats.status = `Active (Last sweep added ${result?.added || 0} leads).`;

      if (queuedCount < 30) {
        await new Promise(resolve => setTimeout(resolve, 3000));
      } else {
        await new Promise(resolve => setTimeout(resolve, 20000));
      }
    } catch (err) {
      console.error('❌ [24/7 Scraper Exception]', err.message);
      scraperStats.status = `Resuming after glitch (${err.message})...`;
      await new Promise(resolve => setTimeout(resolve, 15000));
    }
  }
}

/**
 * Free Fast Scraper: Extracts 10-digit Indian Mobile Numbers (91[6-9]XXXXXXXXX)
 * Searches web search engines (DuckDuckGo HTML) and wellness directories
 */
async function triggerFreeWebScraper(options = {}) {
  const minLeads = options.targetCount || 25;
  console.log(`⚡ [Bemisaal Turbo Scraper] Harvesting Indian health contacts (Target: ${minLeads}+ leads)...`);

  const extracted = [];
  const seenPhonesInBatch = new Set();
  const indianPhoneRegex = /(?:(?:\+91|0091|0)[\s.-]?)?([6-9]\d{2,4}[\s.-]?\d{3,6})\b/g;

  const cityList = options.targetCity ? [options.targetCity] : [...TARGET_INDIAN_CITIES].sort(() => 0.5 - Math.random());
  const nicheList = options.targetNiche ? [options.targetNiche] : [...TARGET_WELLNESS_NICHES].sort(() => 0.5 - Math.random());

  const searchKeywords = [
    'ayurvedic clinic doctor contact 91',
    'herbal sexologist phone contact 91',
    'unani dawakhana mobile number',
    'mardana kamzori ilaj phone number',
    'ayurvedic health centre inquiry contact',
    'gupt rog doctor whatsapp contact 91'
  ];

  for (const city of cityList) {
    if (extracted.length >= minLeads) break;

    for (const kw of searchKeywords) {
      if (extracted.length >= minLeads) break;

      const query = `${kw} ${city}`;
      const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;

      try {
        const res = await fetch(searchUrl, {
          signal: AbortSignal.timeout(7000),
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
          }
        });

        if (!res.ok) continue;
        const html = await res.text();
        const results = [...html.matchAll(/<div class="result results_links results_links_deep web-result ">([\s\S]*?)<\/div>\s*<\/div>\s*<\/div>/g)];

        for (const r of results) {
          if (extracted.length >= minLeads) break;

          const blockHtml = r[1] || '';
          const cleanText = blockHtml.replace(/<[^>]+>/g, ' ');
          const titleMatch = blockHtml.match(/<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/) || blockHtml.match(/<a class="result__url"[^>]*>([\s\S]*?)<\/a>/);
          const rawTitle = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : 'Health Lead';

          let match;
          indianPhoneRegex.lastIndex = 0;
          while ((match = indianPhoneRegex.exec(cleanText)) !== null) {
            const rawPhone = match[0];
            const formatted = formatWhatsAppJid(rawPhone);
            if (formatted && !seenPhonesInBatch.has(formatted.cleanNumber) && !isPhoneAlreadySent(formatted.cleanNumber)) {
              seenPhonesInBatch.add(formatted.cleanNumber);
              extracted.push({
                phone: formatted.cleanNumber,
                name: rawTitle.replace(/[^\w\s]/g, '').slice(0, 30).trim() || 'Bhai',
                source: 'ddg_indian_scraper',
                query: `${city} - ${kw}`
              });
              break;
            }
          }
        }

        // Polite delay between search queries
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (e) {
        // Continue to next query
      }
    }
  }

  // If local sweep found few, fall back to Apify Indian lead queries
  if (extracted.length < minLeads && APIFY_TOKEN) {
    try {
      console.log('🔍 [Apify Indian Search] Expanding search with Apify Google Search...');
      const apifyLeads = await triggerApifyLeadDiscovery();
      if (apifyLeads && apifyLeads.added) {
        extracted.push(...(apifyLeads.leads || []));
      }
    } catch (e) {}
  }

  console.log(`🎯 [Bemisaal Scraper] Extracted ${extracted.length} verified Indian leads.`);
  return addLeadsToQueue(extracted);
}

/**
 * Apify Google Search Scraper targeted for Indian Wellness & Herbal inquiries
 */
async function triggerApifyLeadDiscovery() {
  if (!APIFY_TOKEN) {
    console.warn('⚠️ APIFY_API_TOKEN is missing in environment.');
    return { added: 0 };
  }

  console.log('🔍 [Apify Health Scraper] Searching Indian herbal and men\'s health inquiries...');
  const searchQueries = [
    'mardana kamzori ayurvedic treatment contact number',
    'shighrapatan ilaj whatsapp number hakim',
    'ayurvedic sexologist doctor phone inquiry Delhi',
    'gupt rog clinic contact Mumbai',
    'unani ayurvedic majoon customer inquiry'
  ];

  try {
    const runResponse = await fetch(`https://api.apify.com/v2/acts/apify~google-search-scraper/run-sync-get-dataset-items?token=${APIFY_TOKEN}&memory=512`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        queries: searchQueries.join('\n'),
        maxPagesPerQuery: 1,
        resultsPerPage: 20,
        mobileResults: true,
        languageCode: 'hi'
      })
    });

    if (!runResponse.ok) return { added: 0 };

    const items = await runResponse.json();
    const extracted = [];
    const indianPhoneRegex = /(?:\+91[\s-]?)?(?:0)?[6-9]\d{9}\b/g;

    for (const item of items) {
      const textToSearch = `${item.title || ''} ${item.description || ''} ${item.snippet || ''}`;
      const matches = textToSearch.match(indianPhoneRegex);
      if (matches) {
        for (const phone of matches) {
          const formatted = formatWhatsAppJid(phone);
          if (formatted) {
            extracted.push({
              phone: formatted.cleanNumber,
              name: (item.title || '').replace(/[^\w\s]/g, '').slice(0, 25).trim() || 'Health Lead',
              source: 'apify_google_search',
              query: item.searchQuery || 'herbal inquiry'
            });
          }
        }
      }
    }

    console.log(`🎯 [Apify Health Scraper] Found ${extracted.length} Indian contacts.`);
    return addLeadsToQueue(extracted);
  } catch (err) {
    console.error('❌ Apify Run Failed:', err.message);
    return { added: 0 };
  }
}

function getHotRepliedLeads() {
  const db = loadDatabase();
  return db.leads.filter(l => l.status === 'replied');
}

module.exports = {
  loadDatabase,
  saveDatabase,
  addLeadsToQueue,
  getQueuedLeads,
  getHotRepliedLeads,
  updateLeadStatus,
  triggerFreeWebScraper,
  triggerApifyLeadDiscovery,
  start247ContinuousScraper,
  pauseScraper,
  resumeScraper,
  isPhoneAlreadySent,
  recordSentPhone,
  recordBulkSentPhones,
  getTotalShieldedCount,
  getScraperStats,
  formatWhatsAppJid
};
