/**
 * Multi-Device Enterprise Delivery Cadence Dispatcher for Karnal Realty Advisors
 * (Natural Conversational Scheduler & Account Health Matrix)
 * 
 * Rules:
 * 1. 50 Verified Property Leads Max per 24 hours PER DEVICE (6 Devices = 300 leads/day)
 * 2. Atomic queue claiming ensures NO two devices ever message or touch the same investor
 * 3. 3 to 6 minute natural Gaussian pacing between outreach deliveries
 * 4. Micro-batches of 4 to 7 messages -> followed by scheduled 35 to 65 minute natural rest pauses
 * 5. Operating hours: 9:00 AM IST to 9:00 PM IST (covering India business & NRI timezones)
 * 6. Two-Step Conversational Shield: respectful inquiry verification
 * 7. Supports both Indian Domestic (+91) and Global NRIs (+1 Canada/USA, +44 UK, +61 Australia, +971 UAE)
 */

const ai = require('./ai');
const scraper = require('./scraper');
const whatsapp = require('./whatsapp');

const MAX_DEVICES = parseInt(process.env.MAX_DEVICES || '6', 10);
const DAILY_MAX_LEADS_PER_DEVICE = parseInt(process.env.DAILY_MAX_LEADS_PER_DEVICE || '50', 10);
const MIN_MSG_DELAY_MS = parseInt(process.env.MIN_MSG_DELAY_MS || '180000', 10); // 3 minutes default
const MAX_MSG_DELAY_MS = parseInt(process.env.MAX_MSG_DELAY_MS || '360000', 10); // 6 minutes default
const MIN_BREAK_MINS = parseInt(process.env.MIN_BREAK_MINS || '35', 10);
const MAX_BREAK_MINS = parseInt(process.env.MAX_BREAK_MINS || '65', 10);
const MIN_BATCH_SIZE = parseInt(process.env.MIN_BATCH_SIZE || '4', 10);
const MAX_BATCH_SIZE = parseInt(process.env.MAX_BATCH_SIZE || '7', 10);

let isRunning = false;
let isPaused = false;
let isProactiveScraping = false;
let currentDay = new Date().toDateString();

// Device worker states: deviceId (1..6) -> WorkerState
const deviceStates = new Map();

function getRandomBatchLimit() {
  return Math.floor(MIN_BATCH_SIZE + Math.random() * (MAX_BATCH_SIZE - MIN_BATCH_SIZE + 1));
}

/**
 * Box-Muller Gaussian pacing distribution (3 to 6 minutes bell curve)
 */
function getGaussianMsgDelayMs(minMs = MIN_MSG_DELAY_MS, maxMs = MAX_MSG_DELAY_MS) {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const standardNormal = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  const mean = (minMs + maxMs) / 2;
  const stdDev = (maxMs - minMs) / 6;
  let sample = mean + standardNormal * stdDev;
  if (sample < minMs) sample = minMs + Math.random() * (maxMs - minMs) * 0.08;
  if (sample > maxMs) sample = maxMs - Math.random() * (maxMs - minMs) * 0.08;
  return Math.floor(sample);
}

function getRandomMsgDelayMs() {
  return getGaussianMsgDelayMs(MIN_MSG_DELAY_MS, MAX_MSG_DELAY_MS);
}

function getRandomBreakDurationMs() {
  const mins = MIN_BREAK_MINS + Math.random() * (MAX_BREAK_MINS - MIN_BREAK_MINS);
  return Math.floor(mins * 60 * 1000);
}

function getIndianTimeParts() {
  const now = new Date();
  const istStr = now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
  const istDate = new Date(istStr);
  return {
    hour: istDate.getHours(),
    minute: istDate.getMinutes(),
    dateStr: istDate.toDateString(),
    now
  };
}

function isOperatingHours() {
  // If explicitly overridden in .env
  if (process.env.STRICT_HOURS === 'false') {
    return true;
  }
  const { hour } = getIndianTimeParts();
  // 9:00 AM IST (09:00) to 9:00 PM IST (21:00)
  return (hour >= 9 && hour < 21);
}

function getNext9AmIstTimestamp() {
  const now = new Date();
  const istStr = now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
  const istDate = new Date(istStr);

  const target = new Date(istDate);
  if (istDate.getHours() >= 21) {
    target.setDate(target.getDate() + 1);
  }
  target.setHours(9, 0, 0, 0);

  const diffMs = target.getTime() - istDate.getTime();
  return Date.now() + Math.max(diffMs, 60000);
}

function formatIndiaTime(timestamp) {
  if (!timestamp) return null;
  try {
    return new Date(timestamp).toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }) + ' IST';
  } catch (e) {
    return new Date(timestamp).toLocaleTimeString('en-IN') + ' IST';
  }
}

function checkAndResetDailyCounters() {
  const { dateStr } = getIndianTimeParts();
  if (dateStr !== currentDay) {
    currentDay = dateStr;
    for (const state of deviceStates.values()) {
      state.dailySentCount = 0;
      state.currentBatchCount = 0;
      state.currentBatchLimit = getRandomBatchLimit();
    }
    console.log(`🌅 [Karnal Enterprise Cadence Engine] New calendar day. Reset daily outreach counters to 0/${DAILY_MAX_LEADS_PER_DEVICE} per device.`);
  }
}

function getOrCreateDeviceState(deviceId) {
  let state = deviceStates.get(deviceId);
  if (!state) {
    state = {
      id: deviceId,
      currentBatchCount: 0,
      currentBatchLimit: getRandomBatchLimit(),
      dailySentCount: 0,
      totalSentSession: 0,
      consecutiveFailures: 0,
      nextActionTime: null,
      currentStatus: 'Initializing slot...'
    };
    deviceStates.set(deviceId, state);
  }
  return state;
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Worker loop for an individual WhatsApp device slot
 */
async function runDeviceWorker(deviceId) {
  const state = getOrCreateDeviceState(deviceId);
  console.log(`⚡ [Karnal Worker Device ${deviceId}] Started independent dispatcher (${DAILY_MAX_LEADS_PER_DEVICE} leads/day allocation).`);

  // Stagger startup so all devices don't fire at the exact same moment
  await sleep((deviceId - 1) * 12000);

  while (isRunning) {
    if (isPaused) {
      state.currentStatus = 'Paused by User';
      await sleep(5000);
      continue;
    }

    checkAndResetDailyCounters();

    // 1. Device Daily Enterprise Allocation Check (50 leads/day)
    if (state.dailySentCount >= DAILY_MAX_LEADS_PER_DEVICE) {
      state.currentStatus = `Daily Enterprise Cadence Allocation Completed (${state.dailySentCount}/${DAILY_MAX_LEADS_PER_DEVICE}). Scheduled to resume at 9:00 AM IST tomorrow...`;
      state.nextActionTime = getNext9AmIstTimestamp();
      await sleep(60000);
      continue;
    }

    // 2. Daylight Operating Hours Check (9:00 AM - 9:00 PM IST)
    if (!isOperatingHours()) {
      state.currentStatus = '🌙 Rest Mode (Active 9:00 AM – 9:00 PM IST). Resuming at 9:00 AM IST...';
      state.nextActionTime = getNext9AmIstTimestamp();
      await sleep(60000);
      continue;
    }

    // 3. Check if this specific device is connected
    if (!whatsapp.isDeviceConnected(deviceId)) {
      state.currentStatus = `Waiting for WhatsApp QR scan on /qr?device=${deviceId}...`;
      await sleep(8000);
      continue;
    }

    // 4. Proactive lead harvest if backlog is low
    const remainingInQueue = scraper.getQueuedLeads(30).length;
    if (remainingInQueue < 25 && !isProactiveScraping) {
      isProactiveScraping = true;
      console.log(`⚡ [Continuous Scraper] Queue has ${remainingInQueue} leads. Harvesting fresh real estate leads in background...`);
      scraper.triggerFreeWebScraper({ targetCount: 30, deviceId })
        .catch(e => console.error('Continuous harvest notice:', e.message))
        .finally(() => { isProactiveScraping = false; });
    }

    // 5. Atomic Claim: Grab next unassigned lead for this device territory
    let lead = scraper.claimNextLead(deviceId);
    if (!lead) {
      state.currentStatus = 'Queue Empty: Harvesting fresh Karnal commercial & NRI property leads...';
      try {
        await scraper.triggerFreeWebScraper({ targetCount: 25, deviceId });
      } catch (err) {}
      lead = scraper.claimNextLead(deviceId);
      if (!lead) {
        await sleep(15000);
        continue;
      }
    }

    // 6. Global WhatsApp JID validation
    const jidInfo = scraper.formatWhatsAppJid(lead.phone);
    if (!jidInfo) {
      console.log(`❌ [Device ${deviceId}] Skipped invalid phone number ${lead.phone}.`);
      scraper.updateLeadStatus(lead.phone, 'invalid_number', null, deviceId);
      continue;
    }
    const targetJid = typeof jidInfo === 'string' ? jidInfo : jidInfo.jid;

    // 7. Duplicate & Sent Shield
    if (scraper.isPhoneAlreadySent(lead.phone) || whatsapp.hasExistingChat(lead.phone)) {
      console.log(`⏩ [Device ${deviceId}] +${lead.phone} was already contacted. Skipping!`);
      scraper.updateLeadStatus(lead.phone, 'sent', null, deviceId);
      continue;
    }

    // 8. Verify WhatsApp registration
    state.currentStatus = `Checking WhatsApp status for +${lead.phone}...`;
    const waCheck = await whatsapp.checkNumberOnWhatsApp(deviceId, lead.phone);
    if (!waCheck.exists) {
      console.log(`❌ [Device ${deviceId}] +${lead.phone} is not registered on WhatsApp. Skipping!`);
      scraper.updateLeadStatus(lead.phone, 'not_on_whatsapp', null, deviceId);
      await sleep(300);
      continue;
    }

    lead.jid = waCheck.jid || targetJid;

    // 9. Generate Two-Step Outreach Message
    state.currentStatus = `Preparing personalized outreach for +${lead.phone}...`;
    const outreachText = await ai.generateFirstTouch(lead);

    // 10. Send via WhatsApp through this device
    state.currentStatus = `Sending message to +${lead.phone}...`;
    let sendSucceeded = false;
    try {
      const sent = await whatsapp.sendTextMessage(deviceId, lead.jid, outreachText);
      if (sent) {
        scraper.updateLeadStatus(lead.phone, 'sent', null, deviceId);
        state.currentBatchCount++;
        state.totalSentSession++;
        state.dailySentCount++;
        state.consecutiveFailures = 0;
        sendSucceeded = true;
        console.log(`✅ [Real WhatsApp Sent by Device ${deviceId} (${state.currentBatchCount}/${state.currentBatchLimit})] To +${lead.phone}. Today: ${state.dailySentCount}/${DAILY_MAX_LEADS_PER_DEVICE}`);
      } else {
        state.consecutiveFailures++;
        scraper.updateLeadStatus(lead.phone, 'failed', 'Socket send failure', deviceId);
      }
    } catch (sendErr) {
      state.consecutiveFailures++;
      console.error(`❌ [Device ${deviceId} Send Error]:`, sendErr.message);
      scraper.updateLeadStatus(lead.phone, 'failed', sendErr.message, deviceId);
    }

    // Circuit Breaker: 3 consecutive failures cools down this device socket for 20 mins
    if (state.consecutiveFailures >= 3) {
      state.currentStatus = '⚠️ Circuit Breaker engaged (3 delivery hiccups). Cooling down socket for 20 mins...';
      state.nextActionTime = Date.now() + 20 * 60 * 1000;
      console.log(`\n🛡️ [Circuit Breaker Device ${deviceId}] 3 delivery hiccups detected. Cooling down for 20 mins until ${formatIndiaTime(state.nextActionTime)}...\n`);
      await sleep(20 * 60 * 1000);
      state.consecutiveFailures = 0;
      continue;
    }

    // 11. Human Gaussian Pacing / Micro-Batch Rest Breaks
    if (sendSucceeded) {
      if (state.currentBatchCount >= state.currentBatchLimit) {
        const breakMs = getRandomBreakDurationMs();
        const breakMins = Math.round(breakMs / 60000);
        state.nextActionTime = Date.now() + breakMs;
        state.currentStatus = `Mini-batch of ${state.currentBatchLimit} sent! Taking ${breakMins}-min natural cadence pause...`;
        console.log(`\n☕ [Natural Micro-Batch Rest Device ${deviceId}] Batch target met (${state.currentBatchLimit} sent). Taking ${breakMins}-minute cadence pause until ${formatIndiaTime(state.nextActionTime)}...\n`);

        await sleep(breakMs);

        state.currentBatchCount = 0;
        state.currentBatchLimit = getRandomBatchLimit();
        console.log(`⚡ [Worker Device ${deviceId}] Natural rest completed! Next batch rolled: ${state.currentBatchLimit} leads.`);
      } else {
        // Natural 3 to 6 minute Gaussian pacing between messages
        const gaussianDelayMs = getGaussianMsgDelayMs(MIN_MSG_DELAY_MS, MAX_MSG_DELAY_MS);
        const delaySec = Math.round(gaussianDelayMs / 1000);
        const delayMins = (gaussianDelayMs / 60000).toFixed(1);
        state.nextActionTime = Date.now() + gaussianDelayMs;
        state.currentStatus = `Natural pacing pause: waiting ${delayMins}m (${delaySec}s) before next contact...`;
        console.log(`⏳ [Pacing Device ${deviceId}] Next lead scheduled at ${formatIndiaTime(state.nextActionTime)} (~${delayMins} min Gaussian cadence)...`);
        await sleep(gaussianDelayMs);
      }
    } else {
      await sleep(2000);
    }
  }
}

/**
 * Start queue workers across all devices
 */
function startQueue() {
  if (isRunning) return;
  isRunning = true;
  isPaused = false;
  console.log(`🚀 [Karnal Enterprise Cadence Engine] Starting parallel dispatchers for up to ${MAX_DEVICES} devices...`);

  for (let i = 1; i <= MAX_DEVICES; i++) {
    runDeviceWorker(i).catch(err => {
      console.error(`Fatal crash in Worker Device ${i}:`, err);
    });
  }
}

function pauseQueue() {
  isPaused = true;
  console.log('⏸️ [Karnal Enterprise Cadence Engine] Queue paused across all devices.');
}

function resumeQueue() {
  isPaused = false;
  console.log('▶️ [Karnal Enterprise Cadence Engine] Queue resumed.');
}

function getQueueStatus() {
  const devicesList = [];
  let totalDailySent = 0;
  let totalSessionSent = 0;

  for (let i = 1; i <= MAX_DEVICES; i++) {
    const s = getOrCreateDeviceState(i);
    const dInfo = whatsapp.getDevice(i);
    totalDailySent += s.dailySentCount;
    totalSessionSent += s.totalSentSession;

    devicesList.push({
      id: i,
      deviceId: i,
      isConnected: whatsapp.isDeviceConnected(i),
      phone: dInfo && dInfo.phone ? dInfo.phone : null,
      currentStatus: s.currentStatus,
      dailySentCount: s.dailySentCount,
      dailyLimit: DAILY_MAX_LEADS_PER_DEVICE,
      dailyMaxLeads: DAILY_MAX_LEADS_PER_DEVICE,
      currentBatchCount: s.currentBatchCount,
      currentBatchLimit: s.currentBatchLimit,
      totalSentSession: s.totalSentSession,
      nextActionTime: s.nextActionTime ? formatIndiaTime(s.nextActionTime) : null,
      nextActionTimestamp: s.nextActionTime
    });
  }

  const { hour, minute } = getIndianTimeParts();
  const connectedCount = whatsapp.getConnectedDevices ? whatsapp.getConnectedDevices().length : 0;
  const queuedRemaining = scraper.getQueuedLeads ? scraper.getQueuedLeads(1000).length : 0;
  const stats = scraper.getScraperStats ? scraper.getScraperStats() : {};

  return {
    isRunning,
    isPaused,
    operatingHours: isOperatingHours(),
    currentTimeIST: `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')} IST`,
    connectedDevicesCount: connectedCount,
    maxDevices: MAX_DEVICES,
    dailySentCount: totalDailySent,
    dailyMaxLeads: MAX_DEVICES * DAILY_MAX_LEADS_PER_DEVICE,
    totalDailySent,
    maxDailyCapacity: MAX_DEVICES * DAILY_MAX_LEADS_PER_DEVICE,
    totalSessionSent,
    totalSentDb: stats.totalSent || 0,
    queuedRemaining,
    devices: devicesList
  };
}

module.exports = {
  startQueue,
  startQueueWorker: startQueue,
  pauseQueue,
  resumeQueue,
  getQueueStatus,
  getQueueState: getQueueStatus,
  runDeviceWorker,
  getGaussianMsgDelayMs,
  getRandomBreakDurationMs,
  getRandomBatchLimit
};
