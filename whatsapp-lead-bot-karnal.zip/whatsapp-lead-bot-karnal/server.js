/**
 * Web Dashboard & Control Server for Karnal Realty Advisors
 * Deployable on Render.com & Termux (Multi-Device Real Estate Outreach Edition)
 * Supports up to 6 simultaneous WhatsApp accounts (300 property leads/day total)
 * Features:
 * - Luxury Dark Theme (Navy Obsidian & Emerald/Gold accents)
 * - /qr multi-device switching tab bar
 * - Real-time queue, territory & device status matrix
 * - 1-Click CSV export for Hot Replied Leads
 * - 1-Click CSV export for All Discovered Real Estate Leads
 * - 1-Click TXT phone list download & copyable textarea
 * - Manual investor lead injector & past number shielding
 * - Render anti-sleep keep-alive heartbeat engine
 */

require('dotenv').config();

// Global Process Crash Shield
process.on('uncaughtException', (err) => {
  console.error('🛡️ [Crash Shield - Uncaught Exception]:', err.message);
});
process.on('unhandledRejection', (reason) => {
  console.error('🛡️ [Crash Shield - Unhandled Rejection]:', reason);
});

const express = require('express');
const path = require('path');
const whatsapp = require('./whatsapp');
const scraper = require('./scraper');
const queue = require('./queue');

const app = express();
const PORT = process.env.PORT || 3002;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Anti-Sleep Keep-Alive State & Auto-Host Detection
let detectedBaseUrl = (process.env.RENDER_EXTERNAL_URL || process.env.PUBLIC_URL || '').replace(/\/$/, '');
let keepAliveTimer = null;
let lastPingStatus = 'Pending first ping';
let lastPingTime = 'Never';

function startKeepAliveEngine(targetUrl) {
  if (!targetUrl || keepAliveTimer) return;
  detectedBaseUrl = targetUrl.replace(/\/$/, '');
  console.log(`📡 [Anti-Sleep Keep-Alive] Engaged for: ${detectedBaseUrl}`);
  console.log(`⏱️ [Anti-Sleep Keep-Alive] Pinging ${detectedBaseUrl}/ping every 3 minutes to stop Render Free sleep.`);

  const runPing = async () => {
    try {
      const res = await fetch(`${detectedBaseUrl}/ping`, {
        headers: { 'User-Agent': 'Render-AntiSleep-Heartbeat/3.0' },
        signal: AbortSignal.timeout(10000)
      });
      lastPingStatus = `HTTP ${res.status} OK`;
      lastPingTime = new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' IST';
      console.log(`💓 [Anti-Sleep Heartbeat] Pinged ${detectedBaseUrl}/ping -> ${lastPingStatus} at ${lastPingTime}`);
    } catch (err) {
      lastPingStatus = `Warn: ${err.message}`;
      console.warn('⚠️ [Heartbeat Notice]:', err.message);
    }
  };

  setTimeout(runPing, 5000);
  keepAliveTimer = setInterval(runPing, 3 * 60 * 1000);
}

app.use((req, res, next) => {
  if (!detectedBaseUrl) {
    const proto = req.headers['x-forwarded-proto'] || 'https';
    const host = req.headers['x-forwarded-host'] || req.headers['host'] || req.get('host');
    if (host && !host.includes('localhost') && !host.includes('127.0.0.1')) {
      const resolved = `${proto}://${host}`;
      console.log(`🌐 [Host Auto-Detected] Inbound host captured: ${resolved}`);
      startKeepAliveEngine(resolved);
    }
  }
  next();
});

app.get('/healthz', (req, res) => res.status(200).send('OK'));
app.get('/ping', (req, res) => res.status(200).send('pong'));

/**
 * Multi-Device QR Linking Page (/qr?device=X)
 */
app.get('/qr', (req, res) => {
  const selectedId = parseInt(req.query.device || '1', 10);
  const clampedId = Math.max(1, Math.min(whatsapp.MAX_DEVICES, selectedId));
  const device = whatsapp.getDevice(clampedId);
  const allDevices = whatsapp.getAllDevices();

  const isConnected = device ? device.isConnected : false;
  const phone = device ? device.phone : null;
  const qrDataUrl = device ? device.qrDataUrl : null;

  let bodyContent = '';

  if (isConnected) {
    bodyContent = `
      <div class="card connected">
        <div class="icon">🏢</div>
        <h2>Device ${clampedId} Active &amp; Ready!</h2>
        <p class="phone">+${phone}</p>
        <p class="desc">Connected to Karnal Realty Advisors property desk (50 leads/day anti-ban cap).</p>
        <div style="display: flex; gap: 0.75rem; justify-content: center; flex-wrap: wrap;">
          <a href="/" class="btn btn-gold">Go to Live Dashboard</a>
          <form method="POST" action="/api/devices/${clampedId}/logout" style="margin: 0;">
            <button type="submit" class="btn btn-red" onclick="return confirm('Disconnect Device ${clampedId}?');">🔌 Disconnect / Relink</button>
          </form>
        </div>
      </div>
    `;
  } else if (qrDataUrl) {
    bodyContent = `
      <div class="card">
        <h2>Link Device ${clampedId}</h2>
        <p class="subtitle">Open WhatsApp on Phone ${clampedId} > Linked Devices > Link a Device</p>
        <div class="qr-box">
          <img src="${qrDataUrl}" alt="WhatsApp QR Code for Device ${clampedId}" class="qr-img" />
        </div>
        <p class="refresh-hint">QR automatically refreshes every 5 seconds.</p>
      </div>
      <script>
        setTimeout(() => { window.location.reload(); }, 5000);
      </script>
    `;
  } else {
    bodyContent = `
      <div class="card">
        <div class="spinner"></div>
        <h2>Initializing Device ${clampedId} Socket...</h2>
        <p class="desc">Generating a fresh QR code with Windows 11 Chrome fingerprint, please wait...</p>
      </div>
      <script>
        setTimeout(() => { window.location.reload(); }, 4000);
      </script>
    `;
  }

  // Device Tabs Bar
  const tabsHtml = allDevices.map(d => {
    const isCurrent = d.id === clampedId;
    const label = d.isConnected ? `Device ${d.id} (● +${d.phone ? d.phone.slice(-4) : 'OK'})` : `Device ${d.id} (📱 Link)`;
    const bgClass = d.isConnected ? 'tab-online' : 'tab-offline';
    const activeClass = isCurrent ? 'tab-active' : '';
    return `<a href="/qr?device=${d.id}" class="tab-btn ${bgClass} ${activeClass}">${label}</a>`;
  }).join('');

  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Link WhatsApp Devices — Karnal Realty Advisors</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #070b14; color: #fff; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 1.5rem; }
        .wrapper { max-width: 540px; width: 100%; text-align: center; }
        .header-nav { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
        .back-link { color: #f59e0b; text-decoration: none; font-size: 0.9rem; font-weight: 600; }
        .tabs { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; margin-bottom: 1.5rem; }
        .tab-btn { padding: 0.65rem 0.5rem; border-radius: 10px; text-decoration: none; font-size: 0.8rem; font-weight: 700; border: 1px solid #1e293b; background: #0f172a; color: #94a3b8; transition: all 0.2s; }
        .tab-btn.tab-online { border-color: #10b981; color: #6ee7b7; background: #064e3b33; }
        .tab-btn.tab-active { border-color: #f59e0b; background: #b4530933; color: #fbbf24; }
        .card { background: #0f172a; border: 1px solid #1e293b; border-radius: 20px; padding: 2.25rem 1.75rem; width: 100%; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
        .card.connected { border-color: #10b981; }
        h2 { font-size: 1.4rem; margin-bottom: 0.4rem; color: #f8fafc; }
        .subtitle { color: #94a3b8; font-size: 0.85rem; margin-bottom: 1.25rem; }
        .qr-box { background: #fff; padding: 1rem; border-radius: 16px; display: inline-block; margin-bottom: 1.25rem; }
        .qr-img { width: 240px; height: 240px; display: block; }
        .phone { font-size: 1.25rem; font-weight: 700; color: #34d399; margin: 0.5rem 0 1rem; }
        .desc { color: #94a3b8; font-size: 0.9rem; line-height: 1.5; margin-bottom: 1.5rem; }
        .btn { display: inline-block; padding: 0.65rem 1.25rem; border-radius: 8px; font-weight: 600; text-decoration: none; border: none; cursor: pointer; font-size: 0.9rem; }
        .btn-gold { background: #f59e0b; color: #000; font-weight: 700; }
        .btn-red { background: #dc2626; color: #fff; }
        .refresh-hint { font-size: 0.8rem; color: #64748b; }
        .spinner { width: 40px; height: 40px; border: 4px solid #1e293b; border-top-color: #f59e0b; border-radius: 50%; animation: spin 1s infinite linear; margin: 0 auto 1.25rem; }
        @keyframes spin { 100% { transform: rotate(360deg); } }
      </style>
    </head>
    <body>
      <div class="wrapper">
        <div class="header-nav">
          <a href="/" class="back-link">← Back to Dashboard</a>
          <span style="color: #64748b; font-size: 0.85rem;">Slot <strong>${clampedId}</strong> of ${whatsapp.MAX_DEVICES}</span>
        </div>
        <div class="tabs">
          ${tabsHtml}
        </div>
        ${bodyContent}
      </div>
    </body>
    </html>
  `);
});

/**
 * Main Web Dashboard (/)
 */
app.get('/', (req, res) => {
  const state = queue.getQueueState();
  const scraperStats = scraper.getScraperStats();
  const totalShielded = scraper.getTotalShieldedCount ? scraper.getTotalShieldedCount() : 0;
  const hotLeads = scraper.getHotRepliedLeads ? scraper.getHotRepliedLeads() : [];
  const allLeads = scraper.getAllDiscoveredLeads ? scraper.getAllDiscoveredLeads('all') : [];

  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="refresh" content="8">
      <title>Karnal Realty Advisors — Multi-Device Lead &amp; Outreach Engine</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #070b14; color: #f1f5f9; padding: 1.5rem; }
        .container { max-width: 900px; margin: 0 auto; }
        header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #1e293b; padding-bottom: 1.25rem; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
        h1 { font-size: 1.45rem; color: #fbbf24; }
        .status-badge { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.4rem 0.9rem; border-radius: 9999px; font-size: 0.85rem; font-weight: 700; text-decoration: none; }
        .status-badge.online { background: #064e3b; color: #6ee7b7; border: 1px solid #059669; }
        .status-badge.offline { background: #7f1d1d; color: #fca5a5; border: 1px solid #dc2626; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
        .stat-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 14px; padding: 1.25rem; text-align: center; }
        .stat-val { font-size: 1.7rem; font-weight: 800; color: #fbbf24; margin-top: 0.35rem; }
        .stat-label { font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; }
        .section-box { background: #0f172a; border: 1px solid #1e293b; border-radius: 14px; padding: 1.5rem; margin-bottom: 1.5rem; }
        h3 { font-size: 1.1rem; margin-bottom: 1rem; color: #f8fafc; }
        .btn-group { display: flex; gap: 0.75rem; flex-wrap: wrap; }
        .btn { padding: 0.65rem 1.25rem; border-radius: 8px; font-weight: 600; text-decoration: none; border: none; cursor: pointer; font-size: 0.9rem; }
        .btn-gold { background: #f59e0b; color: #000; font-weight: 700; }
        .btn-emerald { background: #10b981; color: #fff; font-weight: 700; }
        .btn-blue { background: #2563eb; color: #fff; }
        .btn-outline { background: transparent; border: 1px solid #334155; color: #cbd5e1; }
        textarea { width: 100%; height: 90px; background: #070b14; border: 1px solid #334155; border-radius: 8px; color: #fff; padding: 0.75rem; font-size: 0.9rem; margin-bottom: 0.75rem; resize: vertical; }
        .log-box { background: #070b14; padding: 1rem; border-radius: 8px; font-family: monospace; font-size: 0.85rem; color: #94a3b8; line-height: 1.5; }
        .device-row { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; background: #070b14; border-radius: 8px; margin-bottom: 0.5rem; border: 1px solid #1e293b; flex-wrap: wrap; gap: 0.5rem; }
        .device-title { font-weight: 700; color: #f8fafc; font-size: 0.9rem; display: flex; align-items: center; gap: 0.5rem; }
        .device-meta { font-size: 0.8rem; color: #94a3b8; }
        .badge-pill { padding: 0.2rem 0.6rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 700; }
        .badge-online { background: #064e3b; color: #6ee7b7; border: 1px solid #059669; }
        .badge-offline { background: #334155; color: #94a3b8; }
      </style>
    </head>
    <body>
      <div class="container">
        <header>
          <div>
            <h1>🏢 Karnal Realty Advisors — Multi-Device Lead Engine</h1>
            <p style="color: #64748b; font-size: 0.85rem; margin-top: 0.2rem;">
              GT Road Commercial Spaces • SCO Plots • NRI Diaspora (Canada, UK, US, Aus, Dubai) • 100% Real Human Anti-Ban
            </p>
          </div>
          <div>
            ${state.connectedDevicesCount > 0 ?
              `<a href="/qr" class="status-badge online">● ${state.connectedDevicesCount} / ${state.maxDevices} Devices Active</a>` :
              `<a href="/qr" class="status-badge offline">⚠️ Scan Devices QR</a>`
            }
          </div>
        </header>

        <div class="grid">
          <div class="stat-card">
            <div class="stat-label">Active Devices</div>
            <div class="stat-val" style="color: #fbbf24;">${state.connectedDevicesCount} / ${state.maxDevices}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Today's Outreach</div>
            <div class="stat-val" style="color: #34d399;">${state.dailySentCount} / ${state.dailyMaxLeads}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Total Sent (All Time)</div>
            <div class="stat-val">${state.totalSentDb}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Leads In Queue</div>
            <div class="stat-val" style="color: #38bdf8;">${state.queuedRemaining}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Shielded Past Numbers</div>
            <div class="stat-val" style="color: #a855f7;">${totalShielded}</div>
          </div>
          <div class="stat-card" style="border-color: #f59e0b44;">
            <div class="stat-label" style="color: #fde68a;">Hot Replied Leads</div>
            <div class="stat-val" style="color: #f59e0b;">${hotLeads.length}</div>
          </div>
        </div>

        ${req.query.shielded ? `
          <div style="background: #1e1b4b; border: 1px solid #8b5cf6; border-radius: 12px; padding: 1.1rem; margin-bottom: 1.5rem; color: #e9d5ff;">
            🛡️ <strong>Investor Shield Updated!</strong> Permanently shielded <strong>${req.query.count || 0}</strong> numbers from ever receiving outreach again.
          </div>
        ` : ''}

        <!-- Multi-Device Control Center (6 Slots) -->
        <div class="section-box" style="border-left: 4px solid #f59e0b;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
            <div>
              <h3 style="margin: 0; color: #fbbf24;">📱 Multi-Device Territory Matrix (${state.connectedDevicesCount} of ${state.maxDevices} Linked)</h3>
              <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 0.2rem;">
                Isolated sessions: 50 leads/day, 1–2m jitter, 50–80m tea breaks. Partitioned by territory: Commercial, SCOs, Canada, UK, Australia &amp; Haryana HNW.
              </p>
            </div>
            <a href="/qr" class="btn btn-gold" style="font-size: 0.85rem;">+ Link / Manage Devices</a>
          </div>

          <div>
            ${state.devices.map(d => `
              <div class="device-row">
                <div>
                  <div class="device-title">
                    <span>Device ${d.id}</span>
                    <span class="badge-pill ${d.isConnected ? 'badge-online' : 'badge-offline'}">
                      ${d.isConnected ? `● +${d.phone}` : 'Not Linked'}
                    </span>
                  </div>
                  <div class="device-meta" style="margin-top: 0.25rem;">
                    Status: <span style="color: #e2e8f0;">${d.currentStatus}</span>
                    ${d.nextActionTime ? ` • Next: <span style="color: #fbbf24;">${d.nextActionTime}</span>` : ''}
                  </div>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                  <span style="font-weight: 700; color: ${d.dailySentCount >= d.dailyMaxLeads ? '#34d399' : '#fbbf24'}; font-size: 0.9rem;">
                    ${d.dailySentCount} / ${d.dailyMaxLeads} today
                  </span>
                  <a href="/qr?device=${d.id}" class="btn btn-outline" style="padding: 0.35rem 0.75rem; font-size: 0.8rem;">
                    ${d.isConnected ? 'Manage' : '📱 Scan QR'}
                  </a>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Master Pause / Stop Bot Controls -->
        ${state.isPaused ? `
          <div style="background: #450a0a; border: 1px solid #b91c1c; border-radius: 12px; padding: 1.25rem; margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
            <div>
              <h3 style="color: #f87171; margin-bottom: 0.25rem;">🛑 Outreach Engine is PAUSED</h3>
              <p style="color: #fca5a5; font-size: 0.85rem; margin: 0;">Outreach is paused on all devices. All leads, claimed positions, and histories are safe.</p>
            </div>
            <form method="POST" action="/api/queue/resume" style="margin: 0;">
              <button type="submit" class="btn" style="background: #10b981; color: #fff; padding: 0.75rem 1.5rem; font-size: 0.95rem; font-weight: 700; cursor: pointer;">▶️ Resume Outreach</button>
            </form>
          </div>
        ` : `
          <div style="background: #022c22; border: 1px solid #059669; border-radius: 12px; padding: 1.25rem; margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
            <div>
              <h3 style="color: #34d399; margin-bottom: 0.25rem;">⚡ Multi-Device Engine ACTIVE (9:00 AM – 9:00 PM IST)</h3>
              <p style="color: #6ee7b7; font-size: 0.85rem; margin: 0;">Active Daylight Hours • Micro-batches with 1–2m jitter &amp; 50–80m breaks • Commercial &amp; NRI Targeting.</p>
            </div>
            <form method="POST" action="/api/queue/pause" style="margin: 0;">
              <button type="submit" class="btn" style="background: #dc2626; color: #fff; padding: 0.75rem 1.5rem; font-size: 0.95rem; font-weight: 700; cursor: pointer;">🛑 Pause Outreach</button>
            </form>
          </div>
        `}

        <!-- Hot Leads Section with 1-Click CSV Export -->
        <div class="section-box" style="border-left: 4px solid #f59e0b; background: #78350f15;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 0.5rem;">
            <div>
              <h3 style="margin: 0; color: #fbbf24;">🔥 Hot Property Investor Leads (${hotLeads.length})</h3>
              <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 0.2rem;">Investors &amp; buyers who replied to outreach. Ready for closing / site visit booking.</p>
            </div>
            <a href="/api/leads/export-csv" class="btn btn-gold">📥 Download Hot Leads (.CSV)</a>
          </div>
          ${hotLeads.length === 0 ? '<p style="color: #64748b; font-size: 0.85rem;">No replies yet today. As soon as property investors respond, they appear here instantly.</p>' : `
            <div style="max-height: 220px; overflow-y: auto; background: #070b14; border-radius: 8px; padding: 0.5rem;">
              ${hotLeads.slice(-10).reverse().map(l => `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; border-bottom: 1px solid #1e293b;">
                  <div>
                    <strong style="color: #f1f5f9;">+${l.phone}</strong>
                    <span style="color: #94a3b8; font-size: 0.8rem; margin-left: 0.5rem;">${l.name || 'Valued Investor'}</span>
                  </div>
                  <a href="https://wa.me/${l.phone}" target="_blank" class="btn btn-emerald" style="padding: 0.35rem 0.75rem; font-size: 0.8rem; text-decoration: none;">💬 WhatsApp</a>
                </div>
              `).join('')}
            </div>
          `}
        </div>

        <!-- Discovered Leads List & Manager (Turns all leads into a list) -->
        <div class="section-box" style="border-left: 4px solid #10b981; background: #064e3b12;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 0.5rem;">
            <div>
              <h3 style="margin: 0; color: #34d399;">📋 All Discovered Leads List (${allLeads.length} Total in DB)</h3>
              <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 0.2rem;">
                Karnal commercial buyers, SCO investors, and global NRIs. Download or copy as a formatted list below.
              </p>
            </div>
            <div class="btn-group">
              <a href="/api/leads/export-all-csv" class="btn btn-emerald">📥 Export All (.CSV)</a>
              <a href="/api/leads/export-list-txt" class="btn btn-outline">📋 Download Phone List (.TXT)</a>
            </div>
          </div>

          <details style="margin-bottom: 1rem; background: #070b14; padding: 0.75rem; border-radius: 8px; border: 1px solid #1e293b;">
            <summary style="cursor: pointer; color: #34d399; font-weight: 600; font-size: 0.85rem;">📄 Click to view copyable raw numbers list (${allLeads.length} numbers)</summary>
            <textarea readonly style="margin-top: 0.5rem; width: 100%; height: 120px; font-family: monospace; font-size: 0.8rem;" onclick="this.select()">${allLeads.map(l => '+' + l.phone).join('\n')}</textarea>
          </details>

          ${allLeads.length === 0 ? '<p style="color: #64748b; font-size: 0.85rem;">No leads in database yet. Trigger the scraper below to harvest fresh numbers.</p>' : `
            <div style="max-height: 280px; overflow-y: auto; background: #070b14; border-radius: 8px; padding: 0.5rem;">
              ${allLeads.slice(0, 50).map(l => `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; border-bottom: 1px solid #1e293b;">
                  <div>
                    <strong style="color: #f1f5f9;">+${l.phone}</strong>
                    <span style="color: #94a3b8; font-size: 0.8rem; margin-left: 0.5rem;">${l.name || 'Investor'} • ${(l.city || 'Karnal').toUpperCase()}</span>
                    <span class="badge-pill ${l.status === 'replied' ? 'badge-online' : (l.status === 'sent' ? 'badge-online' : 'badge-offline')}" style="margin-left: 0.5rem; font-size: 0.7rem;">
                      ${l.status}
                    </span>
                  </div>
                  <a href="https://wa.me/${l.phone}" target="_blank" class="btn btn-emerald" style="padding: 0.3rem 0.65rem; font-size: 0.75rem; text-decoration: none;">💬 WhatsApp</a>
                </div>
              `).join('')}
            </div>
          `}
        </div>

        <div class="section-box">
          <h3>📥 Add Investor Phone Numbers to Queue</h3>
          <form method="POST" action="/api/leads/add-form">
            <textarea name="numbers" placeholder="Paste phone numbers (India 10-digit/91 or Global NRIs +1, +44, +61, +971)..."></textarea>
            <div class="btn-group">
              <button type="submit" class="btn btn-gold">+ Add to Real Estate Lead Queue</button>
              <a href="/qr" class="btn btn-outline">📱 Scan / Manage Devices</a>
            </div>
          </form>
        </div>

        <div class="section-box" style="border-left: 4px solid #a855f7;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <h3 style="margin: 0; color: #c084fc;">🛡️ Shield Past Investor Numbers (Past Campaigns / Blacklist)</h3>
            <span style="background: #581c87; color: #e9d5ff; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">DUPLICATE SHIELD</span>
          </div>
          <p style="color: #94a3b8; font-size: 0.85rem; margin-bottom: 0.75rem;">
            Paste numbers from past campaigns, spreadsheets, or DND requests below (one per line). They will be recorded in the permanent shield ledger so no device contacts them!
          </p>
          <form method="POST" action="/api/leads/shield-past">
            <textarea name="pastNumbers" placeholder="Paste numbers here (one per line, e.g. 9876543210, +14165551234, etc.)..."></textarea>
            <button type="submit" class="btn" style="background: #7c3aed; color: #fff; font-weight: 700; cursor: pointer;">🛡️ Permanently Shield These Numbers</button>
          </form>
        </div>

        <div class="section-box" style="border-color: #f59e0b; background: #78350f10;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <h3 style="margin: 0; color: #fbbf24;">🌐 Yandex &amp; Global Real Estate Scraper</h3>
            <span style="background: ${scraperStats.isPaused ? '#7f1d1d' : '#065f46'}; color: ${scraperStats.isPaused ? '#fca5a5' : '#a7f3d0'}; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">${scraperStats.isPaused ? 'PAUSED' : 'ACTIVE 24/7'}</span>
          </div>
          <p class="log-box" style="margin-bottom: 0.75rem;">
            Status: <strong>${scraperStats.status}</strong><br>
            Cycles Completed: <strong>${scraperStats.cyclesCompleted}</strong> | Harvested This Session: <strong>${scraperStats.leadsHarvestedSession}</strong> | Total in DB: <strong>${scraperStats.totalInDb}</strong><br>
            Target Territory: <strong>${(scraperStats.lastScrapedCity || 'Karnal').toUpperCase()}</strong> (${scraperStats.lastScrapedNiche || 'Commercial Spaces & SCOs'})
          </p>
          <div class="btn-group">
            <form method="POST" action="/api/scraper/trigger-free-form" style="margin: 0;">
              <button type="submit" class="btn btn-gold">⚡ Trigger Instant Real Estate Sweep (30+ Leads)</button>
            </form>
            <form method="POST" action="${scraperStats.isPaused ? '/api/scraper/resume' : '/api/scraper/pause'}" style="margin: 0;">
              <button type="submit" class="btn btn-outline">${scraperStats.isPaused ? '▶️ Resume Auto-Scraper' : '⏸️ Pause Auto-Scraper'}</button>
            </form>
          </div>
        </div>
      </div>
    </body>
    </html>
  `);
});

/**
 * API Endpoints
 */
app.get('/api/status', (req, res) => {
  res.json({
    devices: whatsapp.getAllDevices(),
    queue: queue.getQueueState()
  });
});

app.get('/api/leads/export-csv', (req, res) => {
  const hotLeads = scraper.getHotRepliedLeads ? scraper.getHotRepliedLeads() : [];
  let csv = 'Phone,Name,City,Status,Updated_At,Direct_WhatsApp_Link\r\n';
  for (const l of hotLeads) {
    const phone = l.phone || '';
    const name = (l.name || 'Valued Investor').replace(/"/g, '""');
    const city = (l.city || 'Karnal').replace(/"/g, '""');
    const status = l.status || 'replied';
    const updated = l.updated_at ? new Date(l.updated_at).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) : 'Recent';
    const waLink = `https://wa.me/${phone}`;
    csv += `+${phone},"${name}","${city}",${status},"${updated}","${waLink}"\r\n`;
  }
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="karnal_realty_hot_leads.csv"');
  res.send(csv);
});

app.get('/api/leads/export-all-csv', (req, res) => {
  const allLeads = scraper.getAllDiscoveredLeads ? scraper.getAllDiscoveredLeads('all') : [];
  let csv = 'Phone,Name,City,Query,Status,Discovered_At,Last_Sent_At,Direct_WhatsApp_Link\r\n';
  for (const l of allLeads) {
    const phone = l.phone || '';
    const name = (l.name || 'Valued Investor').replace(/"/g, '""');
    const city = (l.city || 'Karnal').replace(/"/g, '""');
    const query = (l.query || '').replace(/"/g, '""');
    const status = l.status || 'queued';
    const discovered = l.discoveredAt ? new Date(l.discoveredAt).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) : '';
    const lastSent = l.lastSentAt ? new Date(l.lastSentAt).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) : '';
    const waLink = `https://wa.me/${phone}`;
    csv += `+${phone},"${name}","${city}","${query}",${status},"${discovered}","${lastSent}","${waLink}"\r\n`;
  }
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="karnal_realty_all_discovered_leads.csv"');
  res.send(csv);
});

app.get('/api/leads/export-list-txt', (req, res) => {
  const allLeads = scraper.getAllDiscoveredLeads ? scraper.getAllDiscoveredLeads('all') : [];
  const lines = allLeads.map(l => `+${l.phone}`).join('\r\n');
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Content-Disposition', 'attachment; filename="karnal_realty_phone_numbers.txt"');
  res.send(lines);
});

app.post('/api/devices/:id/logout', async (req, res) => {
  const deviceId = parseInt(req.params.id, 10);
  try {
    await whatsapp.logoutDevice(deviceId);
  } catch (err) {
    console.error(`Logout error for device ${deviceId}:`, err.message);
  }
  res.redirect(`/qr?device=${deviceId}&logged_out=true`);
});

app.post('/api/leads/add-form', (req, res) => {
  const numbersText = req.body.numbers || '';
  const lines = numbersText.split('\n');
  const leads = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed) {
      leads.push({ phone: trimmed, source: 'manual_dashboard' });
    }
  }

  const result = scraper.addLeadsToQueue(leads);
  res.redirect(`/?added=${result.added}`);
});

app.post('/api/leads/shield-past', (req, res) => {
  const numbersText = req.body.pastNumbers || '';
  const lines = numbersText.split('\n');
  const numbersToShield = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed) {
      numbersToShield.push(trimmed);
    }
  }

  const result = scraper.recordBulkSentPhones(numbersToShield);
  res.redirect(`/?shielded=true&count=${result.added}`);
});

app.post('/api/queue/pause', (req, res) => {
  queue.pauseQueue();
  res.redirect('/?paused=true');
});

app.post('/api/queue/resume', (req, res) => {
  queue.resumeQueue();
  res.redirect('/?resumed=true');
});

app.post('/api/scraper/pause', (req, res) => {
  scraper.pauseScraper();
  res.redirect('/?scraper_paused=true');
});

app.post('/api/scraper/resume', (req, res) => {
  scraper.resumeScraper();
  res.redirect('/?scraper_resumed=true');
});

app.post('/api/scraper/trigger-free-form', async (req, res) => {
  try {
    await scraper.triggerFreeWebScraper({ targetCount: 30 });
  } catch (err) {
    console.error('Real Estate Scraper Error:', err);
  }
  res.redirect('/?scraper=free_triggered');
});

function initKeepAlive() {
  if (detectedBaseUrl) {
    startKeepAliveEngine(detectedBaseUrl);
  } else {
    console.log('💡 [Keep-Alive] Waiting for first inbound request or RENDER_EXTERNAL_URL to lock target URL...');
  }
}

/**
 * Start Server, Scraper, WhatsApp Multi-Devices & Queue Workers
 */
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n=========================================================`);
  console.log(`🏢 Karnal Realty Advisors Multi-Device Lead Bot on Port ${PORT}`);
  console.log(`📲 Open http://localhost:${PORT}/qr to link WhatsApp devices (Up to ${whatsapp.MAX_DEVICES})`);
  console.log(`=========================================================\n`);

  // 1. Start autonomous continuous real estate scraper
  scraper.start247ContinuousScraper().catch(e => console.error("24/7 Scraper Boot Error:", e.message));

  // 2. Start Anti-Sleep Keep-Alive Heartbeat
  initKeepAlive();

  // 3. Initialize all 6 device slots
  whatsapp.initAllDevices();

  // 4. Start concurrent queue workers across all devices
  queue.startQueueWorker();
});
