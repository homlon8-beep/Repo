/**
 * Karnal Realty Advisors - Senior Real Estate & Commercial Investment Consultant
 * Specializing in Karnal (GT Road Corridor, Sector 12, Model Town, Urban Estate, SCO Plots)
 * Dedicated Domestic & NRI Investor Desk (Canada, UK, USA, Australia, UAE, India)
 */

const GROQ_API_KEY = process.env.GROQ_API_KEY || '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';
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const BRAND_NAME = process.env.BRAND_NAME || 'Karnal Realty Advisors';
const HELPLINE = process.env.HELPLINE_NUMBER || '+91-9990394794';

const SYSTEM_PROMPT = `You are Aman Sharma, Senior Property Investment Consultant at ${BRAND_NAME} (Karnal, Haryana).
You are professional, courteous, highly knowledgeable about Karnal's real estate market, and completely transparent.

About Karnal Market & Our Prime Portfolio:
1. Commercial Spaces & SCO Plots (Shop-Cum-Offices):
   - Prime locations: GT Road Expressway Corridor, Sector 12 Commercial Hub, Model Town, Urban Estate, Mughal Canal, Kunjpura Road.
   - Types: High-street retail shops, commercial booths, SCO plots with basement + ground + 3 floors approval.
   - Ideal for: High rental yield (8% to 12%), commercial showrooms, banks, restaurants, corporate offices.
2. Residential Plots & Luxury Living:
   - Approved gated townships, RERA & DTP compliant, clear titles, immediate registry & mutation (intkal).
   - Sizes: 100 sq.yd, 150 sq.yd, 250 sq.yd up to 500 sq.yd luxury villa plots.
3. Dedicated NRI Desk (For investors in Canada, UK, USA, Australia, UAE/Dubai):
   - 100% legal compliance, transparent registry, video-call site walkthroughs, and end-to-end leasing management.
4. Transparency Guarantee:
   - Zero hidden fees. 100% bank loan approved from SBI, HDFC, ICICI.

Consultation Rules:
- Language:
  * Default to polished, respectful Hinglish or clean Hindi for domestic Indian contacts.
  * Use clean, professional English for international/NRI contacts (+1, +44, +61, +971).
- Tone: Executive, trustworthy, helpful. Never sound like a cheap broker or aggressive spammer.
- When lead asks for prices/locations:
  * Commercial booths start from approx ₹25 - ₹45 Lakhs; prime SCO plots range from ₹1.2 Cr - ₹3.5 Cr.
  * Residential plots start from ₹35 Lakhs up to ₹1.5 Cr depending on sector & size.
  * Ask them: "Aapka primary objective rental income (commercial) hai ya future living / long-term appreciation (residential plot)?"
- When lead asks for visit / photos:
  * Offer: "Main aapko location map, approved layout aur video right here WhatsApp par share kar deta hoon. Agar aap Karnal me hain, toh weekend par direct site visit schedule kar sakte hain."
- Helpline: ${HELPLINE}`;

/**
 * Call Gemini REST API
 */
async function callGemini(messages, temperature = 0.6) {
  if (!GEMINI_API_KEY) return null;
  try {
    const promptText = messages.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n');
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: promptText }] }],
        generationConfig: {
          temperature: temperature,
          maxOutputTokens: 450
        }
      })
    });
    if (!response.ok) return null;
    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || null;
  } catch (err) {
    return null;
  }
}

/**
 * Call Groq API
 */
async function callGroq(messages, temperature = 0.6) {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: messages,
        temperature: temperature,
        max_tokens: 450
      })
    });
    if (!response.ok) return null;
    const data = await response.json();
    let content = data.choices?.[0]?.message?.content?.trim() || '';
    if (!content && data.choices?.[0]?.message?.reasoning) {
      content = data.choices[0].message.reasoning.trim();
    }
    return content;
  } catch (err) {
    console.error('❌ Groq API Failure:', err.message);
    return null;
  }
}

async function generateAiResponse(messages, temperature = 0.6) {
  if (GEMINI_API_KEY) {
    const geminiRes = await callGemini(messages, temperature);
    if (geminiRes) return geminiRes;
  }
  return await callGroq(messages, temperature);
}

function cleanLeadName(rawName) {
  if (!rawName) return '';
  let name = String(rawName).trim();
  const BANNED = /\b(lead|property|realty|karnal|investor|buyer|commercial|plot|sco|inquiry|client|sir|madam|admin|contact)\b/i;
  if (BANNED.test(name)) return '';
  name = name.replace(/[^\w\s]/g, '').trim();
  if (name.length < 3 || name.length > 20) return '';
  return name.charAt(0).toUpperCase() + name.slice(1);
}

/**
 * Combinatorial Spintax Outreach Templates (Hinglish & Global NRI)
 */
const DOMESTIC_TEMPLATES = [
  // 1. Commercial & High-Yield SCO Focus
  (name) => `${name ? `Namaste ${name} ji!` : 'Namaste ji!'} Karnal Realty Advisors property desk se message tha.\n\nAapki Karnal (GT Road corridor / Sector 12) me commercial space, SCO plots ya high-return property investment ke regarding query mili thi.\n\nKya abhi details aur verified inventory WhatsApp par share karein ya direct discussion arrange karein?\n\n(Reply STOP to opt out)`,

  // 2. Prime Residential & Commercial Plots
  (name) => `Namaste ji, Karnal Realty se message hai.\n\nKarnal me RERA-approved commercial shops aur prime residential plots ke new inventory release hue hain (immediate registry & clear titles).\n\nKya aapka preference commercial rental income me hai ya residential living plot me? Details yahan WhatsApp par provide kar dete hain.\n\n(Reply STOP to opt out)`,

  // 3. Short & Dignified Consultation Check
  (name) => `${name ? `Namaste ${name} ji!` : 'Namaste ji!'} Karnal Realty investment advisory desk se contact kar rahe the.\n\nAapki Karnal property inquiry ke regarding confirm karna tha—kya abhi 2 minute WhatsApp par verified layout maps aur price list share karein?\n\n(Reply STOP to opt out)`
];

const NRI_TEMPLATES = [
  // 1. Global NRI Investment Desk
  (name) => `Hello${name ? ` ${name}` : ''}! Reaching out from Karnal Realty Advisors (NRI Investment Desk).\n\nWe received your inquiry regarding prime commercial SCO plots & luxury residential spaces in Karnal along the Delhi-Chandigarh GT Road expressway.\n\nWould you like a brief digital brochure & ROI breakdown right here on WhatsApp?\n\n(Reply STOP to opt out)`,

  // 2. High-Yield Commercial & Plots
  (name) => `Hi there! Karnal Realty Advisory here.\n\nWe assist overseas NRI investors with 100% legal, clear-title commercial spaces and premium township plots in Karnal with complete leasing management.\n\nAre you looking for commercial rental yield or residential capital growth? Happy to share verified options in chat.\n\n(Reply STOP to opt out)`
];

/**
 * Generate Initial Outreach Message
 */
async function generateOutreachMessage(leadOrName = '') {
  let lead = {};
  if (typeof leadOrName === 'object' && leadOrName !== null) {
    lead = leadOrName;
  } else {
    lead = { name: leadOrName, country: 'India' };
  }

  const validName = cleanLeadName(lead.name);
  const isNri = (lead.country && lead.country !== 'India' && lead.country !== 'IN') || (lead.phone && !String(lead.phone).startsWith('91'));

  if (isNri) {
    const fn = NRI_TEMPLATES[Math.floor(Math.random() * NRI_TEMPLATES.length)];
    return fn(validName);
  } else {
    const fn = DOMESTIC_TEMPLATES[Math.floor(Math.random() * DOMESTIC_TEMPLATES.length)];
    return fn(validName);
  }
}

/**
 * Handle incoming reply from a lead
 */
async function handleIncomingMessage(senderName, incomingText, history = []) {
  const lower = (incomingText || '').toLowerCase().trim();

  // 1. Opt-out
  if (lower === 'stop' || lower === 'unsubscribe' || lower === 'remove' || lower.includes('stop')) {
    return "Aapka number hamari records se remove kar diya gaya hai. Aage se koi message nahi aayega. Best wishes!";
  }

  // 2. Toxic sentiment de-escalation
  const TOXIC_PATTERNS = /\b(scam|fraud|police|cyber|complaint|spam|unsolicited|sue|lawsuit|lawyer|report|reported|harassment|fuck|bhosdike|gandu|harami|fake|jail|court)\b/i;
  if (TOXIC_PATTERNS.test(lower)) {
    return "So sorry for any disturbance! We have removed your number from our records immediately. Wishing you all the best.";
  }

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT }
  ];

  if (Array.isArray(history)) {
    history.slice(-6).forEach(h => {
      messages.push({ role: h.role, content: h.content });
    });
  }

  messages.push({
    role: 'user',
    content: incomingText
  });

  const reply = await generateAiResponse(messages, 0.6);
  if (reply && reply.trim().length > 30) return reply.trim();

  // High-converting default real estate consultation reply
  return `Namaste! Karnal Realty Advisors me connect karne ke liye dhanyawad.\n\nHamare paas Karnal me do primary investment segments hain:\n1. 🏢 Commercial SCO Plots & Retail Spaces (GT Road, Sector 12 & Model Town) – 8% se 12% rental yield ke saath.\n2. 🏡 Prime Gated Residential Plots (100 se 500 gaj) – 100% RERA & DTP approved, clear registry.\n\nAapka budget aur preference commercial rental property me hai ya residential plot me? Main aapko layout aur video details share kar deta hoon.`;
}

module.exports = {
  generateOutreachMessage,
  generateFirstTouch: generateOutreachMessage,
  handleIncomingMessage,
  SYSTEM_PROMPT,
  BRAND_NAME,
  HELPLINE
};
